<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('customers', 'CustomerAccounts::index');
$routes->get('users', 'UserAccounts::index');
$routes->get('customers/new', 'CustomerAccounts::newCustomer');
$routes->post('customers/create', 'CustomerAccounts::create');

$routes->get('customers/edit/(:num)', 'CustomerAccounts::edit/$1');
$routes->post('customers/update/(:num)', 'CustomerAccounts::update/$1');

$routes->get('users/new', 'UserAccounts::newUser');
$routes->post('users/create', 'UserAccounts::create');

$routes->get('users/edit/(:num)', 'UserAccounts::edit/$1');
$routes->post('users/update/(:num)', 'UserAccounts::update/$1');